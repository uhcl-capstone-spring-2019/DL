﻿using Com.Uhcl.UhclNavigator;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.UI;

namespace Com.Uhcl.UhclNavigator
{
    public class AccountHandler : MonoBehaviour
    {
        public InputField emailField;
        public InputField userName;
        public InputField passwordField;
        public InputField reenterPassrodField;

        public Text UserNameTextLable;
        public Text LoginTimeTextLable;

        private readonly string emailRegexPattern = @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z";

        public async void AuthenticateUserAsync()
        {
            string emailID = emailField.text;
            string password = passwordField.text;

            #region Validations

            if (string.IsNullOrEmpty(emailID))
            {
                Debug.Log("Please Enter Email Address.");
                return;
            }

            if (string.IsNullOrEmpty(password))
            {
                Debug.Log("Please Enter Password.");
                return;
            }

            if (password.Length < 6)
            {
                Debug.Log("Password must be atleast 6 characters long.");
                return;
            }

            bool isEmail = Regex.IsMatch(emailID, emailRegexPattern, RegexOptions.IgnoreCase);
            if (!isEmail)
            {
                Debug.Log("Please enter valid email ID.");
                return;
            }

            #endregion

            UserDAL userDalObj = new UserDAL();
            var user = await userDalObj.AuthenticateUserAsync(emailID, password);

            if (user != null)
            {
                FirebaseHelper.currentUser = user;
                //UnityEngine.SceneManagement.SceneManager.LoadScene("create building");
                UnityEngine.SceneManagement.SceneManager.LoadScene("rr");
            }
        }

        public async void CreateUserAsync()
        {
            #region Validations

            if (string.IsNullOrEmpty(emailField.text))
            {
                Debug.Log("Please Enter Email Address.");
                return;
            }

            if (string.IsNullOrEmpty(userName.text))
            {
                Debug.Log("Please Enter User Name.");
                return;
            }

            if (string.IsNullOrEmpty(passwordField.text))
            {
                Debug.Log("Please Enter Password.");
                return;
            }

            if (passwordField.text.Length < 6)
            {
                Debug.Log("Passwor must be atleast 6 characters long.");
                return;
            }

            if (string.IsNullOrEmpty(reenterPassrodField.text))
            {
                Debug.Log("Please Enter Confirm Password.");
                return;
            }

            if (passwordField.text.ToUpperInvariant() != reenterPassrodField.text.ToUpperInvariant())
            {
                Debug.Log("Password and Confirm Password is not Same.");
                return;
            }

            if (!Regex.IsMatch(emailField.text, emailRegexPattern, RegexOptions.IgnoreCase))
            {
                Debug.Log("Please enter valid email ID.");
                return;
            }

            #endregion

            User userData = new User
            {
                EmailID = emailField.text,
                Password = passwordField.text,
                UserName = userName.text,
                IsActive = true,
                IsDeleted = false
            };

            try
            {
                string userID = await new UserDAL().RegisterUserAsync(userData);
                if (!string.IsNullOrEmpty(userID))
                {
                    Debug.Log("User Registered with ID: " + userID);
                }
            }
            catch (Exception ex)
            {
                Debug.LogError(ex.InnerException.Message);
            }

        }

        public void SignOut()
        {
            FirebaseHelper.SignOut();
            UnityEngine.SceneManagement.SceneManager.LoadScene("login");
        }

        public void GoToRegisterScene()
        {
            UnityEngine.SceneManagement.SceneManager.LoadScene("user Registration");
        }

        private void Start()
        {
            if (UnityEngine.SceneManagement.SceneManager.GetActiveScene().name == "Logout")
            {
                if (FirebaseHelper.currentUser != null)
                {
                    var user = FirebaseHelper.currentUser;
                    UserNameTextLable.text = user.UserName;
                    LoginTimeTextLable.text = user.LastLoginTime != DateTime.MinValue ? user.LastLoginTime.ToString() : "N/A";
                }
            }
        }
    } 
}
