﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace Com.Uhcl.UhclNavigator
{
    public class NodesHandler : MonoBehaviour
    {
        private List<PrimaryNode> primaryNodes = new List<PrimaryNode>();
        private static List<Building> allBuildings = new List<Building>();

        #region Primary Nodes Fields
        public InputField primaryNodeName;
        public InputField primaryNodeLat;
        public InputField primaryNodeLong;
        public InputField primaryNodeFloorNo;
        public Dropdown primaryNodeBuildingDrpdn;
        #endregion

        #region Secondary Nodes Fields
        public Dropdown primaryNodeDrpdn;
        public InputField secondaryNodeName;
        public InputField secondaryNodeLatitude;
        public InputField secondaryNodeLongitude;
        public InputField secondaryNodeDistance;
        public InputField secondaryNodeFloorNo;
        public Dropdown secondaryNodeBuildingDrpdn;
        #endregion

        private async void Start()
        {
            allBuildings = await new BuildingDAL().GetBuildingsAsync();
            if (SceneManager.GetActiveScene().name == "neighbor node")
            {
                primaryNodes = await new NodesDAL().GetAllPrimaryNodesAsync();
                foreach (var primaryNode in primaryNodes)
                {
                    primaryNodeDrpdn.options.Add(new Dropdown.OptionData(primaryNode.NodeName));
                }

                foreach (var building in allBuildings)
                {
                    secondaryNodeBuildingDrpdn.options.Add(new Dropdown.OptionData(building.BuildingName));
                }
            }

            if (SceneManager.GetActiveScene().name == "Primary nodes")
            {
                foreach (var building in allBuildings)
                {
                    primaryNodeBuildingDrpdn.options.Add(new Dropdown.OptionData(building.BuildingName));
                }
            }

        }

        public async void CreatePrimaryNode()
        {
            var selectedBuildingName = primaryNodeBuildingDrpdn.options[primaryNodeBuildingDrpdn.value].text;

            #region Validations

            if (string.IsNullOrEmpty(primaryNodeName.text)
                || string.IsNullOrEmpty(primaryNodeLat.text)
                || string.IsNullOrEmpty(primaryNodeLong.text)
                || selectedBuildingName == "--Select--"
                || string.IsNullOrEmpty(primaryNodeFloorNo.text))
            {
                Debug.LogError("Please enter all the fields.");
                return;
            }
            #endregion

            PrimaryNode primaryNode = new PrimaryNode()
            {
                NodeName = primaryNodeName.text,
                Latitude = Convert.ToDouble(primaryNodeLat.text),
                Longitude = Convert.ToDouble(primaryNodeLong.text),
                BuildingID = allBuildings.FirstOrDefault(B => B.BuildingName == selectedBuildingName).BuildingID,
                FloorNo = int.Parse(primaryNodeFloorNo.text)
            };

            try
            {
                string createdNodeID = await new NodesDAL().CreatePrimaryNodeAsync(primaryNode);
                Debug.Log("Primary node created with ID: " + createdNodeID);

                primaryNodeLat.text = string.Empty;
                primaryNodeName.text = string.Empty;
                primaryNodeLong.text = string.Empty;
                primaryNodeBuildingDrpdn.value = 0;
                primaryNodeFloorNo.text = string.Empty;
            }
            catch (Exception ex)
            {
                Debug.LogError(ex.InnerException.Message);
            }
        }

        public async void CreateSecondaryNodeAsync()
        {
            var selectedBuildingName = secondaryNodeBuildingDrpdn.options[secondaryNodeBuildingDrpdn.value].text;

            var primaryNodeName = primaryNodeDrpdn.options[primaryNodeDrpdn.value].text;
            var neighbourNodeName = secondaryNodeName.text;
            var neighbourNodeLat = secondaryNodeLatitude.text;
            var neighbourNodeLong = secondaryNodeLongitude.text;
            var neighbourNodeDist = secondaryNodeDistance.text;
            var neighbourNodeFloorNo = secondaryNodeFloorNo.text;

            if (primaryNodeName == "--Select--")
            {
                Debug.LogError("Please select Primary node.");
                return;
            }

            if (selectedBuildingName == "--Select--")
            {
                Debug.LogError("Please select building.");
                return;
            }

            if (string.IsNullOrEmpty(neighbourNodeName)
                || string.IsNullOrEmpty(neighbourNodeLat)
                || string.IsNullOrEmpty(neighbourNodeLong)
                || string.IsNullOrEmpty(neighbourNodeDist)
                || string.IsNullOrEmpty(neighbourNodeFloorNo))
            {
                Debug.LogError("Please Enter all the fields.");
                return;
            }

            NeighbourNode neighbourNode = new NeighbourNode()
            {
                PrimaryNodeID = primaryNodes.FirstOrDefault(PN => PN.NodeName == primaryNodeName).PrimaryNodeID,
                NeighbourNodeName = neighbourNodeName,
                NeighbourNodeLat = Convert.ToDouble(neighbourNodeLat),
                NeighbourNodeLong = Convert.ToDouble(neighbourNodeLong),
                DistFrmPrimaryNode = Convert.ToDouble(neighbourNodeDist),
                BuildingID = allBuildings.FirstOrDefault(B => B.BuildingName == selectedBuildingName).BuildingID,
                FloorNo = int.Parse(neighbourNodeFloorNo)
            };

            try
            {
                string createdNodeID = await new NodesDAL().CreateNeighbourNodeAsycn(neighbourNode);
                Debug.Log("Neighbour node created with ID: " + createdNodeID);
                primaryNodeDrpdn.value = 0;
                secondaryNodeName.text = string.Empty;
                secondaryNodeLatitude.text = string.Empty;
                secondaryNodeLongitude.text = string.Empty;
                secondaryNodeDistance.text = string.Empty;
                secondaryNodeFloorNo.text = string.Empty;
                secondaryNodeBuildingDrpdn.value = 0;
            }
            catch (Exception ex)
            {
                Debug.LogError(ex.InnerException.Message);
            }

        }
    }
}