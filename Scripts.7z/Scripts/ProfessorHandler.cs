﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace Com.Uhcl.UhclNavigator
{
    public class ProfessorHandler : MonoBehaviour
    {
        public InputField profNameInputField;
        public Dropdown buildingNameDrpdnField;
        public Dropdown roomNameDrpdnField;

        public InputField tempInputField;

        private static List<Building> allBuildings = new List<Building>();
        private static List<Room> filteredRooms = new List<Room>();

        async void Start()
        {
            if (SceneManager.GetActiveScene().name == "Navigation Tester")
                return;

            buildingNameDrpdnField.enabled = false;
            BuildingDAL buildingDAL = new BuildingDAL();
            var allBuildingsResult = await buildingDAL.GetBuildingsAsync();
            if (allBuildingsResult != null && allBuildingsResult.Any())
            {
                allBuildings = allBuildingsResult;
                buildingNameDrpdnField.enabled = true;

                foreach (var item in allBuildings)
                {
                    buildingNameDrpdnField.options.Add(new Dropdown.OptionData(item.BuildingName));
                }
            }
        }

        public async void OnChangeBuildingDrpdn()
        {
            string buildingName = buildingNameDrpdnField.options[buildingNameDrpdnField.value].text;
            Building selectedBuilding = allBuildings.FirstOrDefault(B => B.BuildingName == buildingName);
            string buildingID = selectedBuilding != null ? selectedBuilding.BuildingID : string.Empty;

            if (buildingName == "--Select--")
            {
                EmptyRoomDropDown();
            }
            else
            {
                try
                {
                    RoomDAL roomDAL = new RoomDAL();
                    roomNameDrpdnField.enabled = false;
                    EmptyRoomDropDown();
                    var buildingRooms = await roomDAL.getRoomsByBuildingIDAsync(buildingID);
                    roomNameDrpdnField.enabled = true;

                    if (buildingRooms != null && buildingRooms.Any())
                    {
                        filteredRooms = buildingRooms;
                        foreach (var room in buildingRooms)
                        {
                            roomNameDrpdnField.options.Add(new Dropdown.OptionData(room.RoomNo));
                        }
                    }
                    else
                    {
                        EmptyRoomDropDown();
                    }

                }
                catch (System.Exception ex)
                {
                    Debug.LogError(ex.InnerException.Message);
                    EmptyRoomDropDown();
                    roomNameDrpdnField.enabled = true;
                }
            }
        }

        private void EmptyRoomDropDown()
        {
            filteredRooms.Clear();
            roomNameDrpdnField.options.Clear();
            roomNameDrpdnField.options.Add(new Dropdown.OptionData("--Select--"));
            roomNameDrpdnField.value = 0;
        }

        public async void CreateProfessor()
        {
            var professorName = profNameInputField.text;
            var roomName = roomNameDrpdnField.options[roomNameDrpdnField.value].text;
            var buildingName = buildingNameDrpdnField.options[buildingNameDrpdnField.value].text;

            #region Validations

            if (string.IsNullOrEmpty(profNameInputField.text))
            {
                Debug.LogError("Please enter professor name.");
                return;
            }

            if (roomName == "--Select--")
            {
                Debug.LogError("Please select Room no.");
                return;
            }

            if (buildingName == "--Select--")
            {
                Debug.LogError("Please select Building name.");
                return;
            }
            #endregion

            string buildingID = string.Empty;
            string roomID = string.Empty;

            Building selectedBuilding = allBuildings.FirstOrDefault(B => B.BuildingName == buildingName);
            Room selectedRoom = filteredRooms.FirstOrDefault(R => R.RoomNo == roomName);

            if (selectedBuilding != null)
                buildingID = selectedBuilding.BuildingID;

            if (selectedRoom != null)
                roomID = selectedRoom.RoomID;

            Professor professor = new Professor()
            {
                ProfessorName = profNameInputField.text,
                BuildingID = buildingID,
                RoomID = roomID
            };

            ProfessorDAL professorDAL = new ProfessorDAL();

            try
            {
                string profID = await professorDAL.CreateProfessorAsync(professor);
                profNameInputField.text = string.Empty;
                buildingNameDrpdnField.value = 0;
                Debug.Log("Professor created with ID: " + profID);
            }
            catch (System.Exception ex)
            {
                Debug.LogError(ex.InnerException.Message);
            }
        }

        public async void GetProfessorByName()
        {
            if (string.IsNullOrEmpty(tempInputField.text))
                return;

            var result = await new ProfessorDAL().GetProfessorByName(tempInputField.text);

            foreach (var item in result)
            {
                Debug.Log(item.ProfessorName);

                var Prof = await new ProfessorDAL().GetProfessorByID(item.ProfessorID);

                if (Prof != null) Debug.Log("Hiiiii");
            }

        }

    }
}
