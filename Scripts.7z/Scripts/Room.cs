﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Com.Uhcl.UhclNavigator
{
    public class Room
    {
        public string RoomID { get; set; }
        [SerializeField]
        private string roomNo;
        [SerializeField]
        private double latitude;
        [SerializeField]
        private double longitude;
        [SerializeField]
        private string buildingID;
        [SerializeField]
        private int floorNo;
        [SerializeField]
        private string categoryID;
        [SerializeField]
        private string colliderID;
        [SerializeField]
        private string roomName;
        //  [SerializeField]
        private bool isExterior;

        public Building buildingDetail { get; set; }

        public string RoomNo
        {
            get { return roomNo; }
            set { roomNo = value; }
        }

        public double Latitude
        {
            get { return latitude; }
            set { latitude = value; }
        }

        public double Longitude
        {
            get { return longitude; }
            set { longitude = value; }
        }

        public string BuildingID
        {
            get { return buildingID; }
            set { buildingID = value; }
        }

        public int FloorNo
        {
            get { return floorNo; }
            set { floorNo = value; }
        }

        public string CategoryID
        {
            get { return categoryID; }
            set { categoryID = value; }
        }

        public string ColliderID
        {
            get { return colliderID; }
            set { colliderID = value; }
        }

        public bool IsExterior
        {
            get { return isExterior; }
            set { isExterior = value; }
        }

        public string RoomName { get { return roomName; } set { roomName = value; } }

    }
}
