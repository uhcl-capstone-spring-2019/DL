/*
*    Title: Business layer common data
*    Author: Varshithanand Kotipalli
*    Date: 10/20/2018
*    last updated 12/01/2018
*    Code version: 1.0
*/

using Com.Uhcl.UhclNavigator;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace Com.Uhcl.UhclNavigator
{
    public class Astar : MonoBehaviour
    {
        public async void Start()
        {
            Debug.Log("start");
            //await;
            Com.Uhcl.UhclNavigator.NodesDAL nd = new Com.Uhcl.UhclNavigator.NodesDAL();
            //Get all nodes from NodesDAL
            List<PrimaryNode> allNodes = await nd.GetAllPrimaryNodesAsync();
            //List to store all nodes (Nodes class created in this code)

            List<Node> allNodesList = new List<Node>();
            //Dictionary to store a single Node
            Dictionary<string, Node> NodesHash = new Dictionary<string, Node>();
            //Convert all primary nodes to Node class
            foreach (var myNode in allNodes)
            {
                Node newNode = new Node() { NodeID = myNode.NodeName, NodeX = myNode.Latitude, NodeY = myNode.Longitude, NeighbourNodes = new List<Node>(), DistanceDict = new Dictionary<Node, double>() };
                //Debug.Log("newNode: " + newNode);
                Debug.Log("newNode: " + newNode.NodeID + "lat: " + newNode.NodeX + " long: " + newNode.NodeY);
                NodesHash[myNode.NodeName] = newNode;
                allNodesList.Add(newNode);
            }
            //Store Neighbours for all Nodes
            foreach (var Node in allNodes)
            {
                List<NeighbourNode> neighbourNodes = await nd.GetNeighborNodesByPrimaryNodeName(Node.NodeName);
                Debug.Log("neighbourNodes: " + neighbourNodes.Count);
                Node myNode = NodesHash[Node.NodeName];
                //Debug.Log("neighbourNodes count: " + neighbourNodes.Count);
                //Debug.Log("neighbourNodes data: " + neighbourNodes);
                Dictionary<Node, double> distHash = myNode.DistanceDict;
                List<Node> myNeighbourNodes = myNode.NeighbourNodes;
                foreach (var No in neighbourNodes)
                {
                    Node neighbour = NodesHash[No.NeighbourNodeName];
                    distHash[neighbour] = No.DistFrmPrimaryNode;
                    myNeighbourNodes.Add(neighbour);
                }
                // Debug.Log(myNeighbourNodes.Count);
                myNode.DistanceDict = distHash;
                myNode.NeighbourNodes = myNeighbourNodes;
                // Debug.Log(" neighbonode: "+myNode.NeighbourNodes+" dist :"+myNode.DistanceDict);
            }
            //Get the Node nearest to the start Node
            Node start = NearestNodeToStart(new Node() { NodeID = "s", NodeX = 29.57761944, NodeY = -95.10391111 }, allNodesList);
            //Get the Node nearest to the goal Node
            Node goal = NearestNodeToGoal(new Node() { NodeID = "d", NodeX = 29.57760278, NodeY = -95.10416667 }, allNodesList);
            //run Astar
            //Console.WriteLine("calling to calculate f");
            List<Node> path = CalculateF(start, goal);

            Debug.Log(path.Count);
            foreach (var a in path)
            {
                Debug.Log(a.NodeID+":"+a.NodeX+":"+a.NodeY);
            }
        }
        /*
            Takes as input a node and list of all nodes
            Return the nearest node to the given node
        */
        public static Node NearestNodeToStart(Node startNode, List<Node> allNodesList)
        {
            Debug.Log("finding nearest node to start");
            double minDistance = double.MaxValue;
            Node minNode = new Node();
            for (int i = 0; i < allNodesList.Count; i++)
            {
                double distanceNn = Math.Pow(allNodesList[i].NodeX - startNode.NodeX, 2) + Math.Pow(allNodesList[i].NodeY - startNode.NodeY, 2);
                double distance = Math.Sqrt(distanceNn);
                if (distance < minDistance)
                {
                    minDistance = distance;
                    minNode = allNodesList[i];
                }

            }
            Debug.Log("Nerest node to start is: " + minNode.NodeID);
            return minNode;
        }
        /*
            Takes as input a node and list of all nodes
            Return the nearest node to the given node

            It also sets the distance to the goal Node in Node.NodeF (Heuristic)
        */
        public static Node NearestNodeToGoal(Node n, List<Node> allNodesList)
        {
            Debug.Log("finding nearest node to goal");
            double minDistance = double.MaxValue;
            Node minNode = new Node();
            Debug.Log(n.NodeID + "," + n.NodeX);
            for (int i = 0; i < allNodesList.Count; i++)
            {
                double distanceNn = Math.Pow(allNodesList[i].NodeX - n.NodeX, 2) + Math.Pow(allNodesList[i].NodeY - n.NodeY, 2);
                double temp = Math.Sqrt(distanceNn);
                if (temp < minDistance)
                {
                    minDistance = temp;
                    minNode = allNodesList[i];
                }

                double distanceNng = Math.Pow(allNodesList[i].NodeX - minNode.NodeX, 2) + Math.Pow(allNodesList[i].NodeY - minNode.NodeY, 2);
                double temp1 = Math.Sqrt(distanceNng);
                allNodesList[i].NodeDG = temp1;
            }
            Debug.Log("Nearest node to goal is: " + minNode.NodeID);
            return minNode;
        }

        public static List<Node> CalculateF(Node start, Node goal)
        {
            List<Node> openList = new List<Node>();
            HashSet<Node> closedList = new HashSet<Node>();
            //set the curNode to the start
            Node curNode = start;
            curNode.NodeG = 0.0;
            //Using dictionary for getting path
            Dictionary<Node, Node> parent = new Dictionary<Node, Node>();
            parent[curNode] = null;
            while (!(curNode.NodeID).Equals(goal.NodeID))
            {   //get g value
                double g = curNode.NodeG;
                //get all neighbours of cur node
                List<Node> neighbourList = curNode.NeighbourNodes;
                Dictionary<Node, double> dist = curNode.DistanceDict;
                foreach (var Nod in neighbourList)
                {   //check if node is in closedList
                    bool alreadyVisited = false;
                    if (closedList.Contains(Nod))
                    {
                        alreadyVisited = true;
                    }
                    if (!alreadyVisited)
                    {
                        //calculate f value
                        double d = dist[Nod];
                        double h = Nod.NodeDG;
                        double f = g + d + h;
                        Nod.NodeG += d;
                        int index = openList.FindIndex(x => x.NodeID == Nod.NodeID);
                        if (index != -1)
                        {   //check if f value of that node is greater or less
                            if (openList[index].NodeF > f || openList[index].NodeF == 0.0D)
                            {
                                parent[openList[index]] = curNode;
                                openList[index].NodeF = f;
                            }
                        }
                        else
                        {
                            openList.Add(Nod);
                            parent[openList[index + 1]] = curNode;
                            Nod.NodeF = f;
                        }
                    }
                }
                //add the curNode to the closedList
                closedList.Add(curNode);
                openList.Sort(Node.CompareF);
                //continue with the min f valued node
                curNode = openList[0];
                openList.Remove(openList[0]);
            }
            closedList.Add(curNode);
            List<Node> path = new List<Node>();
            foreach (var Node in closedList)
            {

                path.Add(Node);
            }
            return path;
        }
    }
    
    public class Node
    {
        public string NodeID { get; set; }
        public double NodeX { get; set; }
        public double NodeY { get; set; }
        public double NodeF { get; set; }
        public double NodeD { get; set; }
        public double NodeG { get; set; }
        public double NodeDG { get; set; }
        public List<Node> NeighbourNodes { get; set; }
        public Dictionary<Node, double> DistanceDict { get; set; }
        public static Comparison<Node> CompareD = delegate (Node Object1, Node Object2)
        {
            return Object1.NodeD.CompareTo(Object2.NodeD);
        };
        public static Comparison<Node> CompareDG = delegate (Node Object1, Node Object2)
        {
            return Object1.NodeDG.CompareTo(Object2.NodeDG);
        };
        public static Comparison<Node> CompareF = delegate (Node Object1, Node Object2)
        {
            return Object1.NodeF.CompareTo(Object2.NodeF);
        };
        public void AddNodeD(double d)
        {
            NodeD = d;
        }
        public void AddNodeDG(double d)
        {
            NodeDG = d;
        }
        public void AddNodeG(double g)
        {
            NodeG = g;
        }

        public void AddNodeF(double f)
        {
            NodeF = f;
        }

    }
}

