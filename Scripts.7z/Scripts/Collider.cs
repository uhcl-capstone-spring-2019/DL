﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace Com.Uhcl.UhclNavigator
{
    [Serializable]
    public class Collider
    {

        public string ColliderID { get; set; }

        public string colliderName;
        public string colliderShape;
    }

}