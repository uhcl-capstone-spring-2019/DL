﻿
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class map : MonoBehaviour
{
    string url = "";
    public float lat = 24.917828f;
    public float lon = 67.097096f;
    LocationInfo li;
    public int zoom = 14;
    public int mapwidth = 640;
    public int mapheight = 640;
    public enum maptype { roadmap, satellite, hybrid, terrain };
    public maptype mapselected;
    public int scale;
    private bool loadingMap = false;
    private IEnumerator mapcoroutine;
    IEnumerator GetGoogleMap(float lat, float lon)
    {
        //url = "https://maps.googleapis.com/maps/api/staticmap?center=Brooklyn+Bridge,New+York,NY&zoom=13&size=600x300&maptype=roadmap&markers=color:blue%7Clabel:S%7C40.702147,-74.015794&markers=color:green%7Clabel:G%7C40.711614,-74.012318&markers=color:red%7Clabel:C%7C40.718217,-73.998284&key=AIzaSyCjGyHU0ozc2qcB9HywsXXV7F_pE5OOmwA"; 
        url = "https://maps.googleapis.com/maps/api/staticmap?center=" + lat + "," + lon + "&zoom=" + zoom + "&size=" + mapwidth + "x" + mapheight + "&scale=" + scale + "&maptype=" + mapselected + "&key=AIzaSyCjGyHU0ozc2qcB9HywsXXV7F_pE5OOmwA";
        loadingMap = true;
        WWW www = new WWW(url);
        yield return www;
        loadingMap = false;
        gameObject.GetComponent<RawImage>().texture = www.texture;
        StopCoroutine(mapcoroutine);


    }

    // Use this for initialization
    void Start()
    {
        mapcoroutine = GetGoogleMap(lat, lon);
        StartCoroutine(mapcoroutine);

    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.M))
        {
            Debug.Log("new map");
            lat = 40.6786806f;
            lon = -073.8644250f;
            mapcoroutine = GetGoogleMap(lat, lon);
            StartCoroutine(mapcoroutine);
        }

    }
}

