﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Threading.Tasks;
using System.Linq;

namespace Com.Uhcl.UhclNavigator
{
    public class RouterHandler : MonoBehaviour
    {

        public InputField bssidInputField;
        public InputField latitudeInputField;
        public InputField longitudeInputField;
        public InputField floorInputField;
        public Dropdown buildingDrpdn;
        public Dropdown routerTypeDrpdn;

        private static List<Building> allBuildings = new List<Building>();

        private async void Start()
        {
            if (buildingDrpdn != null)
            {
                try
                {
                    List<Building> allBuildingsResult = await new BuildingDAL().GetBuildingsAsync();
                    if (allBuildingsResult != null)
                    {
                        allBuildings = allBuildingsResult;
                        foreach (var building in allBuildings)
                        {
                            buildingDrpdn.options.Add(new Dropdown.OptionData(building.BuildingName));
                        }
                    }
                }
                catch (Exception ex)
                {
                    Debug.LogError(ex.InnerException.Message);
                }
            }
        }

        public async void CreateRouterAsync()
        {
            string buildingName = buildingDrpdn.options[buildingDrpdn.value].text;

            #region Validations
            if (string.IsNullOrEmpty(bssidInputField.text) ||
                    string.IsNullOrEmpty(longitudeInputField.text) ||
                    string.IsNullOrEmpty(latitudeInputField.text) ||
                    string.IsNullOrEmpty(floorInputField.text) ||
                    buildingName == "--Select--")
            {
                Debug.Log("Please enter proper data.");
                return;
            } 
            #endregion

            Building selectedBuilding = allBuildings.FirstOrDefault(B => B.BuildingName == buildingName);
            string buildingID = selectedBuilding != null ? selectedBuilding.BuildingID : string.Empty;

            Router router = new Router
            {
                BSSID = bssidInputField.text,
                Latitude = Convert.ToDouble(latitudeInputField.text),
                Longitude = Convert.ToDouble(longitudeInputField.text),
                Floor = Convert.ToInt32(floorInputField.text),
                BuildingID = buildingID,
                RouterType = routerTypeDrpdn.options[routerTypeDrpdn.value].text
            };

            try
            {
                string routerID = await new RouterDAL().CreateRouterAsync(router);
                Debug.Log("Router created with ID: " + routerID);
            }
            catch (Exception ex)
            {
                Debug.LogError(ex.InnerException.Message);
            }

            // Reset
            bssidInputField.text = "";
            latitudeInputField.text = "";
            longitudeInputField.text = "";
            floorInputField.text = "";
            buildingDrpdn.value = 0;
        }

        public void GetAllRouters()
        {
            // called this method on next button to  Test the code only.
            new RouterDAL().GetAllRoutersAsync().ContinueWith(T =>
            {
                if (!T.IsFaulted)
                {
                    var list = T.Result;
                    Debug.Log("Router Count : " + list.Count);
                }
            });
        }

    }

}