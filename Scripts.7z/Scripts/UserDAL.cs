﻿using Firebase.Auth;
using Firebase.Database;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;
using UnityEngine;

namespace Com.Uhcl.UhclNavigator
{
    public class UserDAL
    {
        public async Task<string> RegisterUserAsync(User userData)
        {
            string userID = string.Empty;
            userData.CreatedOn = DateTime.Now;
            userData.UserRoles = new List<string>();
            userData.UserRoles.Add("User");

            FirebaseUser result = await FirebaseHelper.auth.CreateUserWithEmailAndPasswordAsync(userData.EmailID, userData.Password);
            if (result != null)
            {
                userID = result.UserId;
                var jsonString = JsonUtility.ToJson(userData);
                await FirebaseHelper.dbRef.Child("Users").Child(userID).SetRawJsonValueAsync(jsonString);
            }
            return userID;
        }

        public async Task<User> AuthenticateUserAsync(string emailID, string password)
        {
            User user = null;
            FirebaseUser result = null;
            try
            {
                result = await FirebaseHelper.auth.SignInWithEmailAndPasswordAsync(emailID, password);
            }
            catch (Exception ex)
            {
                Debug.Log("Unable to Login: " + ex.InnerException.Message);
                return user;
            }

            if (result != null)
            {
                user = new User
                {
                    UserID = result.UserId,
                    EmailID = result.Email
                };

                var userDataTask = FirebaseHelper.dbRef.Child("Users").Child(user.UserID).GetValueAsync();

                var setLastLoginTimeTask = FirebaseHelper.dbRef.Child("Users").Child(user.UserID).Child("lastLoginTimestamp").SetValueAsync(DateTime.Now.Ticks);

                DataSnapshot userRoleSnapshot = await userDataTask;

                if (userRoleSnapshot != null && userRoleSnapshot.ChildrenCount > 0)
                {
                    var userDataDictionary = userRoleSnapshot.Value as IDictionary<string, object>;

                    if (userDataDictionary.ContainsKey("userName"))
                        user.UserName = userDataDictionary["userName"].ToString();

                    if (userDataDictionary.ContainsKey("lastLoginTimestamp"))
                        user.LastLoginTime = new DateTime(Convert.ToInt64(userDataDictionary["lastLoginTimestamp"]));

                    if (userDataDictionary.ContainsKey("createdOnTimestamp"))
                        user.CreatedOn = new DateTime(Convert.ToInt64(userDataDictionary["createdOnTimestamp"]));

                    if (userDataDictionary.ContainsKey("isActive"))
                        user.IsActive = Convert.ToBoolean(userDataDictionary["isActive"]);

                    if (userDataDictionary.ContainsKey("isDeleted"))
                        user.IsDeleted = Convert.ToBoolean(userDataDictionary["isDeleted"]);

                    if (userDataDictionary.ContainsKey("roles"))
                    {
                        var userRoles = userDataDictionary["roles"] as IList;

                        user.UserRoles = new List<string>();
                        foreach (var role in userRoles)
                        {
                            user.UserRoles.Add(role.ToString());
                        }
                    }
                }

                await setLastLoginTimeTask;

            }

            return user;
        }
    }

}
