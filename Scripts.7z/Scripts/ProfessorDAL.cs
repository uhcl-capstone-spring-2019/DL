﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UnityEngine;

namespace Com.Uhcl.UhclNavigator
{
    public class ProfessorDAL
    {
        public async Task<string> CreateProfessorAsync(Professor professorData)
        {
            string profID = Guid.NewGuid().ToString().Replace("-", "");
            professorData.CreatedOn = DateTime.Now;
            string profDataJson = JsonUtility.ToJson(professorData);
            var task = FirebaseHelper.dbRef.Child("Professors").Child(profID).SetRawJsonValueAsync(profDataJson);
            await task;
            if (task.IsCompleted && task.IsFaulted)
            {
                profID = string.Empty;
            }
            return profID;
        }

        public async Task<List<Professor>> GetProfessorByName(string professorName)
        {
            if (string.IsNullOrEmpty(professorName))
                throw new ArgumentNullException("professorName");

            List<Professor> professors = new List<Professor>();

            var result = await FirebaseHelper.dbRef.Child("Professors").OrderByChild("professorName").EqualTo(professorName).GetValueAsync();

            if (result == null || result.Value == null) return professors;

            var profDict = result.Value as IDictionary<string, object>;

            Professor professor;
            foreach (var item in profDict)
            {
                professor = new Professor();
                professor.ProfessorID = item.Key;
                var profData = item.Value as IDictionary<string, object>;

                if (profData.ContainsKey("professorName")) professor.ProfessorName = profData["professorName"].ToString();

                if (profData.ContainsKey("buildingID")) professor.BuildingID = profData["buildingID"].ToString();

                if (profData.ContainsKey("roomID")) professor.RoomID = profData["roomID"].ToString();

                if (profData.ContainsKey("createdOnTimestamp")) professor.CreatedOn = new DateTime(Convert.ToInt64(profData["createdOnTimestamp"]));

                professors.Add(professor);
            }

            if (professors != null && professors.Any())
            {
                RoomDAL roomDal = new RoomDAL();
                foreach (var prof in professors)
                {
                    prof.RoomDetails = await roomDal.GetRoomByRoomID(prof.RoomID);
                }
            }

            return professors;
        }

        public async Task<Professor> GetProfessorByID(string professorID)
        {
            if (string.IsNullOrEmpty(professorID)) throw new ArgumentNullException("professorID");

            Professor professor = null;

            var resultedSnapshot = await FirebaseHelper.dbRef.Child("Professors").Child(professorID).GetValueAsync();

            if (resultedSnapshot == null || resultedSnapshot.Value == null) return professor;

            professor = new Professor
            {
                ProfessorID = resultedSnapshot.Key
            };

            var professorDict = resultedSnapshot.Value as IDictionary<string, object>;

            if (professorDict.ContainsKey("professorName")) professor.ProfessorName = professorDict["professorName"].ToString();

            if (professorDict.ContainsKey("buildingID")) professor.BuildingID = professorDict["buildingID"].ToString();

            if (professorDict.ContainsKey("roomID")) professor.RoomID = professorDict["roomID"].ToString();

            if (professorDict.ContainsKey("createdOnTimestamp")) professor.CreatedOn = new DateTime(Convert.ToInt64(professorDict["createdOnTimestamp"]));

            if (professor != null)
                professor.RoomDetails = await new RoomDAL().GetRoomByRoomID(professor.RoomID);

            return professor;
        }

        public async Task<List<Professor>> GetAllProfessors()
        {
            List<Professor> professors = new List<Professor>();

            var resultedSnapshot = await FirebaseHelper.dbRef.Child("Professors").GetValueAsync();

            if (resultedSnapshot == null || resultedSnapshot.Value == null) return professors;

            var professorDict = resultedSnapshot.Value as IDictionary<string, object>;

            Professor professor;

            RoomDAL roomdal = new RoomDAL();

            foreach (var prof in professorDict)
            {
                professor = new Professor
                {
                    ProfessorID = prof.Key
                };

                var professorData = prof.Value as IDictionary<string, object>;

                if (professorData.ContainsKey("professorName")) professor.ProfessorName = professorData["professorName"].ToString();
                if (professorData.ContainsKey("buildingID")) professor.BuildingID = professorData["buildingID"].ToString();
                if (professorData.ContainsKey("roomID")) professor.RoomID = professorData["roomID"].ToString();
                if (professorData.ContainsKey("createdOnTimestamp")) professor.CreatedOn = new DateTime(Convert.ToInt64(professorData["createdOnTimestamp"]));

                professor.RoomDetails = await roomdal.GetRoomByRoomID(professor.RoomID);

                professors.Add(professor);
            }

            return professors;
        }

        public async Task<Room> GetProfessorRoomByProfessorID(string professorID)
        {
            Professor professor = await GetProfessorByID(professorID);

            if (professor == null) return null;

            Room professorRoom = await new RoomDAL().GetRoomByRoomID(professor.RoomID);

            if (professorRoom == null) return null;

            return professorRoom;
        }

        public async Task<Professor> GetProfessorByRoomID(string roomID)
        {
            var snapshot = await FirebaseHelper.dbRef.Child("Professors").OrderByChild("roomID").EqualTo(roomID).GetValueAsync();
            //var snapshot = await FirebaseHelper.dbRef.Child("Professors").Child("roomID").EqualTo(roomID).GetValueAsync();


            if (snapshot == null || snapshot.Value == null) return null;

            var allProf = snapshot.Value as IDictionary<string, object>;

            var firstProf = allProf.FirstOrDefault();

            Professor professor = new Professor() { ProfessorID = firstProf.Key };

            var professorDict = firstProf.Value as IDictionary<string, object>;

            if (professorDict.ContainsKey("professorName")) professor.ProfessorName = professorDict["professorName"].ToString();
            if (professorDict.ContainsKey("buildingID")) professor.BuildingID = professorDict["buildingID"].ToString();
            if (professorDict.ContainsKey("roomID")) professor.RoomID = professorDict["roomID"].ToString();
            if (professorDict.ContainsKey("createdOnTimestamp")) professor.CreatedOn = new DateTime(Convert.ToInt64(professorDict["createdOnTimestamp"]));

            if (professor != null)
                professor.RoomDetails = await new RoomDAL().GetRoomByRoomID(professor.RoomID);

            return professor;
        }

        public async Task<Professor> GetProfessorByRoomNo(string roomNo)
        {
            var roomDetails = await new RoomDAL().GetRoomByRoomNo(roomNo);
            if (roomDetails == null) return null;

            Professor professor = await GetProfessorByRoomID(roomDetails.RoomID);

            if (professor != null)
                professor.RoomDetails = roomDetails;

            return professor;
        }

    }
}
