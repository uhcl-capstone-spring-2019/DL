﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Com.Uhcl.UhclNavigator
{
    public class RoomCategory
    {
        public string RoomCategoryID { get; set; }
        public string Category { get; set; }
    }
}