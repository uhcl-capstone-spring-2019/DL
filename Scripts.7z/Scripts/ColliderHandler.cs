﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace Com.Uhcl.UhclNavigator
{
    public class ColliderHandler : MonoBehaviour
    {

        public InputField colliderNameInputField;
        public Dropdown colliderShapeDrpdn;

        public async void CreateColliderAsync()
        {
            Collider collider = new Collider()
            {
                colliderName = colliderNameInputField.text,
                colliderShape = colliderShapeDrpdn.options[colliderShapeDrpdn.value].text
            };

            #region Validations
            if (string.IsNullOrEmpty(collider.colliderName))
            {
                Debug.LogError("Please enter collider name.");
            }

            if (string.IsNullOrEmpty(collider.colliderShape))
            {
                Debug.LogError("Please select collider shape.");
            }
            #endregion

            try
            {
                ColliderDAL colliderDal = new ColliderDAL();
                string colliderID = await colliderDal.CreateColliderAsync(collider);
                if (!string.IsNullOrEmpty(colliderID))
                {
                    Debug.Log("Collider created with id: " + colliderID);
                }
            }
            catch (System.Exception ex)
            {
                Debug.LogError(ex.InnerException.Message);
            }
        }


    }
}
