﻿using Com.Uhcl.UhclNavigator;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class RoomHandler : MonoBehaviour
{

    public InputField roomCatField;

    public InputField roomNoField;
    public InputField latitudeField;
    public InputField longitudeField;
    public Dropdown buildingDrpdn;
    public InputField floorField;
    public Dropdown roomCategoryDrpdn;
    public Dropdown colliderDrpdn;
    public InputField roomNameField;
    //public Dropdown IsExteriorDrpdn;

    private static List<Building> allBuildings = new List<Building>();
    private static List<RoomCategory> allRoomCategories = new List<RoomCategory>();
    private static List<Com.Uhcl.UhclNavigator.Collider> allColliders = new List<Com.Uhcl.UhclNavigator.Collider>();

    public async void Start()
    {
        if (SceneManager.GetActiveScene().name == "Create Room")
        {
            var buildingsTask = new BuildingDAL().GetBuildingsAsync();
            var roomCatTask = new RoomDAL().GetAllRoomCategoriesAsync();
            var collidersTask = new ColliderDAL().GetAllCollidersAsync();

            List<Building> allBuildingsResult = await buildingsTask;

            if (allBuildingsResult != null)
            {
                allBuildings = allBuildingsResult;
                foreach (var building in allBuildings)
                {
                    buildingDrpdn.options.Add(new Dropdown.OptionData(building.BuildingName));
                }
            }

            List<RoomCategory> allRoomCategoriesResult = await roomCatTask;

            if (allRoomCategoriesResult != null)
            {
                allRoomCategories = allRoomCategoriesResult;
                foreach (var roomCategory in allRoomCategories)
                {
                    roomCategoryDrpdn.options.Add(new Dropdown.OptionData(roomCategory.Category));
                }
            }

            allColliders = await collidersTask;

            if (allColliders != null)
            {
                foreach (var item in allColliders)
                {
                    colliderDrpdn.options.Add(new Dropdown.OptionData(item.colliderName));
                }
            }
        }
    }

    public void CreateRoomCategory()
    {
        if (!string.IsNullOrEmpty(roomCatField.text))
        {
            new RoomDAL().CreateRoomCategoryAsync(roomCatField.text);
            roomCatField.text = string.Empty;
        }
        else
        {
            Debug.Log("Room category cannot be empty.");
        }
    }

    public void OnClickNextBtn()
    {
        new RoomDAL().GetAllRoomCategoriesAsync().ContinueWith(T =>
        {

            if (!T.IsFaulted)
            {
                foreach (RoomCategory item in T.Result)
                {
                    Debug.Log(item.Category);
                }
            }

        });
    }

    public async void CreateRoom()
    {
        string buildingName = buildingDrpdn.options[buildingDrpdn.value].text;
        string roomCatagName = roomCategoryDrpdn.options[roomCategoryDrpdn.value].text;
        string colliderName = colliderDrpdn.options[colliderDrpdn.value].text;
        #region Validations

        if (string.IsNullOrEmpty(roomNoField.text) && string.IsNullOrEmpty(roomNameField.text))
        {
            Debug.Log("Enter either Room No. or Room Name.");
            return;
        }

        if (string.IsNullOrEmpty(latitudeField.text) ||
            string.IsNullOrEmpty(longitudeField.text) ||
            string.IsNullOrEmpty(floorField.text) ||
            buildingName == "--Select--" ||
            roomCatagName == "--Select--" ||
            colliderName == "--Select--")
        {
            Debug.Log("Please Enter Proper Data.");
            return;
        }
        #endregion

        Building selectedBuilding = allBuildings.FirstOrDefault(B => B.BuildingName == buildingName);
        string buildingID = selectedBuilding != null ? selectedBuilding.BuildingID : string.Empty;

        RoomCategory selectedRoomCat = allRoomCategories.FirstOrDefault(R => R.Category == roomCatagName);
        string roomCatID = selectedRoomCat != null ? selectedRoomCat.RoomCategoryID : string.Empty;

        Com.Uhcl.UhclNavigator.Collider selectedCldr = allColliders.FirstOrDefault(C => C.colliderName == colliderName);
        string colliderID = selectedCldr != null ? selectedCldr.ColliderID : string.Empty;

        Room room = new Room()
        {
            RoomNo = roomNoField.text,
            RoomName = roomNameField.text,
            Latitude = Convert.ToDouble(latitudeField.text),
            Longitude = Convert.ToDouble(longitudeField.text),
            BuildingID = buildingID,
            FloorNo = Convert.ToInt32(floorField.text),
            CategoryID = roomCatID,
            ColliderID = colliderID,
            //   IsExterior = Convert.ToBoolean(IsExteriorDrpdn.options[IsExteriorDrpdn.value].text)
        };

        try
        {
            string roomID = await new RoomDAL().CreateRoomAsync(room);

            if (!string.IsNullOrEmpty(roomID))
                Debug.Log("Room Created Successfully With ID: " + room.RoomID);

            roomNoField.text = string.Empty;
            latitudeField.text = string.Empty;
            longitudeField.text = string.Empty;
            floorField.text = string.Empty;
            buildingDrpdn.value = 0;
            roomCategoryDrpdn.value = 0;
        }
        catch (Exception ex)
        {
            Debug.LogError(ex.InnerException.Message);
        }

    }

    public void GetAllRooms()
    {
        new RoomDAL().GetAllRoomsAsync().ContinueWith(T =>
        {
            if (!T.IsFaulted)
            {
                var list = T.Result;
                Debug.Log("Room count : " + list.Count);
            }
        });
    }

}

