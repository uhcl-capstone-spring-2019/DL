﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Firebase;
using Firebase.Auth;
using Firebase.Database;
using Firebase.Unity.Editor;

namespace Com.Uhcl.UhclNavigator
{
    public static class FirebaseHelper
    {
        private static readonly string _databaseURL = "https://uhcl-navigator-c5e5e.firebaseio.com/";
        private static FirebaseUser firebaseUser;
        public static DatabaseReference dbRef;
        public static FirebaseAuth auth;
        public static User currentUser;

        static FirebaseHelper()
        {
            InitialiseFirebaseIfNot();
        }

        private static void InitialiseFirebaseIfNot()
        {
            try
            {
                // Authentication Object Initialization
                if (auth == null)
                {
                    auth = FirebaseAuth.DefaultInstance;
                    Debug.Log("Firebase default instance created.");
                }
                
                auth.StateChanged += Auth_StateChanged;
                //Auth_StateChanged(this, null);

                // Database Object Initialization
                FirebaseApp app = FirebaseApp.DefaultInstance;
                if (string.IsNullOrEmpty(app.GetEditorDatabaseUrl()))
                {
                    app.SetEditorDatabaseUrl(_databaseURL);
                    Debug.Log("Firebase database URL Set.");
                }

                if (dbRef == null)
                {
                    dbRef = FirebaseDatabase.DefaultInstance.RootReference;
                    Debug.Log("Firebase database object initialized.");
                }
            }
            catch (System.Exception ex)
            {
                Debug.LogError(ex.InnerException.Message);
            }
        }

        private static void Auth_StateChanged(object sender, System.EventArgs e)
        {
            Debug.Log("Auth Status Changed.");
            if (auth.CurrentUser != firebaseUser)
            {
                bool signedIn = firebaseUser != auth.CurrentUser && auth.CurrentUser != null;
                if (!signedIn && firebaseUser != null)
                {
                    Debug.Log("Signed out " + firebaseUser.UserId);
                }
                firebaseUser = auth.CurrentUser;
                if (signedIn)
                {
                    Debug.Log("Signed in " + firebaseUser.UserId);
                }
            }
        }

        public static void SignOut()
        {
            auth.SignOut();
            currentUser = null;
            firebaseUser = null;
        }
    }
}