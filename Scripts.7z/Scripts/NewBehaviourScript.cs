﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Com.Uhcl.UhclNavigator
{
    [Serializable]
    public class POI
    {
        public string PoiID { get; set; }
        public string Name;
        public string TableName;
        public string TableColumnName;
        public bool isExterior;
    }
}

