﻿using Firebase.Database;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UnityEngine;

namespace Com.Uhcl.UhclNavigator
{
    public class BuildingDAL
    {
        /// <summary>
        /// Saves a building record to firebase database.
        /// </summary>
        /// <param name="buildingData">Building model.</param>
        /// <returns>Returns newly created building ID.</returns>
        public string CreateBuildingAsync(Building buildingData)
        {
            string buildingID = Guid.NewGuid().ToString().Replace("-", "");
            try
            {
                string buildingJson = JsonUtility.ToJson(buildingData);
                FirebaseHelper.dbRef.Child("buildings").Child(buildingID).SetRawJsonValueAsync(buildingJson).ContinueWith(T =>
                {
                    if (T.Exception != null && T.Exception.InnerExceptions != null && T.Exception.InnerExceptions.Count > 0)
                    {
                        Debug.LogError("Error while creating building: " + T.Exception.InnerExceptions[0].Message);
                    }
                    else
                    {
                        Debug.Log("Building Created With ID : " + buildingID);
                    }
                });
            }
            catch (Exception ex)
            {
                Debug.LogError("Building not created. Error: " + ex.Message);
                buildingID = string.Empty;
            }

            return buildingID;
        }

        /// <summary>
        /// Deletes building record from firebase database.
        /// </summary>
        /// <param name="buildingData">Building Model with Building ID.</param>
        /// <returns>True if building is deleted.</returns>
        public bool DeleteBuildingAsync(Building buildingData)
        {
            bool isDeleted = false;

            var tsk = FirebaseHelper.dbRef.Child("buildings").Child(buildingData.BuildingID).RemoveValueAsync();

            if (tsk.IsCompleted && !tsk.IsFaulted) isDeleted = true;

            return isDeleted;
        }

        /// <summary>
        /// Updates a building record in firebase database.
        /// </summary>
        /// <param name="buildingData">Building data which needs to be updated.</param>
        /// <returns>True if building is updated successfull else returns false.</returns>
        public bool UpdateBuildingAsync(Building buildingData)
        {
            bool isUpdated = false;


            return isUpdated;
        }

        /// <summary>
        /// Gives a list of all the buildings which are in firebase databse.
        /// </summary>
        /// <returns>List of Building Model.</returns>
        public async Task<List<Building>> GetBuildingsAsync()
        {
            List<Building> buildingList = new List<Building>();
            DataSnapshot buildingSnapshot = await FirebaseHelper.dbRef.Child("buildings").GetValueAsync();

            if (buildingSnapshot != null && buildingSnapshot.ChildrenCount > 0)
            {
                var allBuildings = buildingSnapshot.Value as IDictionary<string, object>;
                Building buildingObj;

                foreach (var building in allBuildings)
                {
                    var buildingData = building.Value as IDictionary<string, object>;
                    buildingObj = new Building();
                    buildingObj.BuildingID = building.Key;
                    if (buildingData.ContainsKey("buildingName")) buildingObj.BuildingName = buildingData["buildingName"].ToString();
                    if (buildingData.ContainsKey("latitude")) buildingObj.Latitude = Convert.ToDouble(buildingData["latitude"]);
                    if (buildingData.ContainsKey("longitude")) buildingObj.Longitude = Convert.ToDouble(buildingData["longitude"]);
                    if (buildingData.ContainsKey("isActive")) buildingObj.IsActive = Convert.ToBoolean(buildingData["isActive"]);
                    //   if (buildingData.ContainsKey("isExterior")) buildingObj.IsExterior = Convert.ToBoolean(buildingData["isExterior"]);
                    buildingList.Add(buildingObj);
                }
            }

            return buildingList;
        }

        /// <summary>
        /// Gets building details with building ID.
        /// </summary>
        /// <param name="buildingID"></param>
        /// <returns></returns>
        public async Task<Building> GetBuildingByBuildingID(string buildingID)
        {
            Building building = null;

            DataSnapshot x = await FirebaseHelper.dbRef.Child("buildings").Child(buildingID).GetValueAsync();

            if (x == null || x.Value == null) return null;

            building = new Building() { BuildingID = x.Key };

            var buildingData = x.Value as IDictionary<string, object>;

            if (buildingData.ContainsKey("buildingName")) building.BuildingName = buildingData["buildingName"].ToString();
            if (buildingData.ContainsKey("latitude")) building.Latitude = Convert.ToDouble(buildingData["latitude"]);
            if (buildingData.ContainsKey("longitude")) building.Longitude = Convert.ToDouble(buildingData["longitude"]);
            if (buildingData.ContainsKey("isActive")) building.IsActive = Convert.ToBoolean(buildingData["isActive"]);
            // if (buildingData.ContainsKey("isExterior")) building.IsExterior = Convert.ToBoolean(buildingData["isExterior"]);

            return building;
        }

        public async Task<Building> GetBuildingByBuildingName(string buildingName)
        {
            Building building = null;

            DataSnapshot buildingSnapshot = await FirebaseHelper.dbRef.Child("buildings").OrderByChild("buildingName").EqualTo(buildingName).GetValueAsync();

            if (buildingSnapshot == null || buildingSnapshot.Value == null) return null;

            var multipleBuildings = buildingSnapshot.Value as IDictionary<string, object>;

            var firstbuild = multipleBuildings.FirstOrDefault();

            building = new Building() { BuildingID = firstbuild.Key };

            var buildingData = firstbuild.Value as IDictionary<string, object>;

            if (buildingData.ContainsKey("buildingName")) building.BuildingName = buildingData["buildingName"].ToString();
            if (buildingData.ContainsKey("latitude")) building.Latitude = Convert.ToDouble(buildingData["latitude"]);
            if (buildingData.ContainsKey("longitude")) building.Longitude = Convert.ToDouble(buildingData["longitude"]);
            if (buildingData.ContainsKey("isActive")) building.IsActive = Convert.ToBoolean(buildingData["isActive"]);
            //  if (buildingData.ContainsKey("isExterior")) building.IsExterior = Convert.ToBoolean(buildingData["isExterior"]);

            return building;
        }
    }
}
