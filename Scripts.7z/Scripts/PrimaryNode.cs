﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace Com.Uhcl.UhclNavigator
{
    public class PrimaryNode
    {
        public string PrimaryNodeID { get; set; }

        public string NodeName;
        public double Latitude;
        public double Longitude;
        public string BuildingID;
        public int FloorNo;
    } 
}
