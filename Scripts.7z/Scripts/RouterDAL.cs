﻿using Firebase.Database;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;
using UnityEngine;

namespace Com.Uhcl.UhclNavigator
{
    public class RouterDAL
    {
        public async Task<string> CreateRouterAsync(Router routerData)
        {
            string routerID = Guid.NewGuid().ToString().Replace("-", "");
            var createRouterTask = FirebaseHelper.dbRef.Child("Routers").Child(routerID).SetRawJsonValueAsync(JsonUtility.ToJson(routerData));
            await createRouterTask;
            if (createRouterTask.IsFaulted)
            {
                routerID = string.Empty;
            }

            return routerID;
        }

        public async Task<List<Router>> GetAllRoutersAsync()
        {
            List<Router> allRouters = new List<Router>();
            DataSnapshot routerSnapshot = await FirebaseHelper.dbRef.Child("Routers").GetValueAsync();
            
            if (routerSnapshot != null && routerSnapshot.ChildrenCount > 0)
            {
                var routerDictionary = routerSnapshot.Value as IDictionary<string, object>;
                Router router = null;
                foreach (var item in routerDictionary)
                {
                    router = new Router();
                    router.RouterID = item.Key;
                    IDictionary<string, object> otherRouterData = item.Value as IDictionary<string, object>;
                    if (otherRouterData.ContainsKey("bssid")) router.BSSID = otherRouterData["bssid"].ToString();
                    if (otherRouterData.ContainsKey("buildingID")) router.BuildingID = otherRouterData["buildingID"].ToString();
                    if (otherRouterData.ContainsKey("floor")) router.Floor = Convert.ToInt32(otherRouterData["floor"]);
                    if (otherRouterData.ContainsKey("latitude")) router.Latitude= Convert.ToDouble(otherRouterData["latitude"]);
                    if (otherRouterData.ContainsKey("longitude")) router.Longitude = Convert.ToDouble(otherRouterData["longitude"]);
                    if (otherRouterData.ContainsKey("routerType")) router.RouterType = otherRouterData["routerType"].ToString();
                    allRouters.Add(router);
                }
            }

            return allRouters;
        }

    }
}

