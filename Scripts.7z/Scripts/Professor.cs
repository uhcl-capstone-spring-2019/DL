﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Com.Uhcl.UhclNavigator
{
    [Serializable]
    public class Professor
    {
        [SerializeField]
        private string professorName;
        [SerializeField]
        private string buildingID;
        [SerializeField]
        private string roomID;
        [SerializeField]
        private long createdOnTimestamp;

        private string professorID;
        private DateTime createdOn;

        public string ProfessorName { get { return professorName; } set { professorName = value; } }
        public string BuildingID { get { return buildingID; } set { buildingID = value; } }
        public string RoomID { get { return roomID; } set { roomID = value; } }
        public string ProfessorID { get { return professorID; } set { professorID = value; } }

        public DateTime CreatedOn
        {
            get { return createdOn; }
            set
            {
                createdOn = value;
                createdOnTimestamp = value.Ticks;
            }
        }

        public Room RoomDetails { get; set; }
    }
}
