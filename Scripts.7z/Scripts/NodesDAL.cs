﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UnityEngine;

namespace Com.Uhcl.UhclNavigator
{
    public class NodesDAL
    {
        /// <summary>
        /// Creates new primary node and returns id of created primary node.
        /// </summary>
        /// <param name="primaryNodeData"></param>
        /// <returns></returns>
        public async Task<string> CreatePrimaryNodeAsync(PrimaryNode primaryNodeData)
        {
            primaryNodeData.PrimaryNodeID = Guid.NewGuid().ToString().Replace("-", "");

            var task = FirebaseHelper.dbRef.Child("PrimaryNodes").Child(primaryNodeData.PrimaryNodeID).SetRawJsonValueAsync(JsonUtility.ToJson(primaryNodeData));

            await task;

            if (task.IsFaulted)
                primaryNodeData.PrimaryNodeID = string.Empty;

            return primaryNodeData.PrimaryNodeID;
        }

        /// <summary>
        /// Returns all the primary nodes.
        /// </summary>
        /// <returns></returns>
        public async Task<List<PrimaryNode>> GetAllPrimaryNodesAsync()
        {
            List<PrimaryNode> allPrimaryNodes = new List<PrimaryNode>();

            var resultedSnapshot = await FirebaseHelper.dbRef.Child("PrimaryNodes").GetValueAsync();

            if (resultedSnapshot == null)
                return allPrimaryNodes;

            var nodesDict = resultedSnapshot.Value as IDictionary<string, object>;

            PrimaryNode currentNode;
            foreach (var nodeItem in nodesDict)
            {
                currentNode = new PrimaryNode();
                currentNode.PrimaryNodeID = nodeItem.Key;
                var nodesData = nodeItem.Value as IDictionary<string, object>;

                if (nodesData.ContainsKey("NodeName"))
                    currentNode.NodeName = nodesData["NodeName"].ToString();

                if (nodesData.ContainsKey("Latitude"))
                    currentNode.Latitude = Convert.ToDouble(nodesData["Latitude"]);

                if (nodesData.ContainsKey("Longitude"))
                    currentNode.Latitude = Convert.ToDouble(nodesData["Longitude"]);

                if (nodesData.ContainsKey("BuildingID"))
                    currentNode.BuildingID = nodesData["BuildingID"].ToString();

                if (nodesData.ContainsKey("FloorNo"))
                    currentNode.FloorNo = Convert.ToInt32(nodesData["FloorNo"]);

                allPrimaryNodes.Add(currentNode);
            }


            return allPrimaryNodes;
        }

        /// <summary>
        /// Gets primary node by its name.
        /// </summary>
        /// <param name="primaryNodeName"></param>
        /// <returns></returns>
        public async Task<PrimaryNode> GetPrimaryNodeByName(string primaryNodeName)
        {
            PrimaryNode primaryNode = null;

            var primaryNodeSnapshot = await FirebaseHelper.dbRef.Child("PrimaryNodes").OrderByChild("NodeName").EqualTo(primaryNodeName).GetValueAsync();

            if (primaryNodeSnapshot.Value == null) return primaryNode;

            var primaryNodeDict = primaryNodeSnapshot.Value as IDictionary<string, object>;

            var firstNode = primaryNodeDict.FirstOrDefault();
            primaryNode = new PrimaryNode
            {
                PrimaryNodeID = firstNode.Key
            };

            var primaryNodeData = firstNode.Value as IDictionary<string, object>;

            if (primaryNodeData.ContainsKey("NodeName"))
                primaryNode.NodeName = primaryNodeData["NodeName"].ToString();

            if (primaryNodeData.ContainsKey("Latitude"))
                primaryNode.Latitude = Convert.ToDouble(primaryNodeData["Latitude"]);

            if (primaryNodeData.ContainsKey("Longitude"))
                primaryNode.Longitude = Convert.ToDouble(primaryNodeData["Longitude"]);

            if (primaryNodeData.ContainsKey("BuildingID"))
                primaryNode.BuildingID = primaryNodeData["BuildingID"].ToString();

            if (primaryNodeData.ContainsKey("FloorNo"))
                primaryNode.FloorNo = Convert.ToInt32(primaryNodeData["FloorNo"]);

            return primaryNode;
        }

        /// <summary>
        /// Returns primary node details of given ID.
        /// </summary>
        /// <param name="primaryNodeID"></param>
        /// <returns></returns>
        public async Task<PrimaryNode> GetPrimaryNodeByID(string primaryNodeID)
        {
            PrimaryNode primaryNode = null;

            var primaryNodeSnapshot = await FirebaseHelper.dbRef.Child("PrimaryNodes").Child(primaryNodeID).GetValueAsync();

            if (primaryNodeSnapshot.Value == null) return primaryNode;

            primaryNode = new PrimaryNode
            {
                PrimaryNodeID = primaryNodeSnapshot.Key
            };

            var primaryNodeData = primaryNodeSnapshot.Value as IDictionary<string, object>;

            if (primaryNodeData.ContainsKey("NodeName"))
                primaryNode.NodeName = primaryNodeData["NodeName"].ToString();

            if (primaryNodeData.ContainsKey("Latitude"))
                primaryNode.Latitude = Convert.ToDouble(primaryNodeData["Latitude"]);

            if (primaryNodeData.ContainsKey("Longitude"))
                primaryNode.Latitude = Convert.ToDouble(primaryNodeData["Longitude"]);

            if (primaryNodeData.ContainsKey("BuildingID"))
                primaryNode.BuildingID = primaryNodeData["BuildingID"].ToString();

            if (primaryNodeData.ContainsKey("FloorNo"))
                primaryNode.FloorNo = Convert.ToInt32(primaryNodeData["FloorNo"]);

            return primaryNode;
        }

        /// <summary>
        /// Creates neighbour nodes and returns id of the created neighbor node.
        /// </summary>
        /// <param name="neighbourNode"></param>
        /// <returns></returns>
        public async Task<string> CreateNeighbourNodeAsycn(NeighbourNode neighbourNode)
        {
            neighbourNode.NeighbourNodeID = Guid.NewGuid().ToString().Replace("-","");
            var task = FirebaseHelper.dbRef.Child("NeighbourNodes").Child(neighbourNode.NeighbourNodeID).SetRawJsonValueAsync(JsonUtility.ToJson(neighbourNode));
            await task;
            if (task.IsFaulted)
            {
                neighbourNode.NeighbourNodeID = string.Empty;
            }
            return neighbourNode.NeighbourNodeID;
        }

        /// <summary>
        /// This method returns all the neighbor nodes of the given primary node ID.
        /// </summary>
        /// <returns>List of all the neighbor nodes.</returns>
        public async Task<List<NeighbourNode>> GetNeighborNodesByPrimaryNodeID(string primaryNodeID)
        {
            List<NeighbourNode> neighborNodes = new List<NeighbourNode>();

            var resultedSnapshot = await FirebaseHelper.dbRef.Child("NeighbourNodes").OrderByChild("PrimaryNodeID").EqualTo(primaryNodeID).GetValueAsync();
            if (resultedSnapshot == null || resultedSnapshot.Value == null) return neighborNodes;

            var nodesDict = resultedSnapshot.Value as IDictionary<string, object>;

            NeighbourNode neighbourNode;
            foreach (var node in nodesDict)
            {
                neighbourNode = new NeighbourNode
                {
                    NeighbourNodeID = node.Key
                };

                var neighborNodeData = node.Value as IDictionary<string, object>;

                if (neighborNodeData.ContainsKey("NeighbourNodeName"))
                    neighbourNode.NeighbourNodeName = neighborNodeData["NeighbourNodeName"].ToString();

                if (neighborNodeData.ContainsKey("NeighbourNodeLat"))
                    neighbourNode.NeighbourNodeLat = Convert.ToDouble(neighborNodeData["NeighbourNodeLat"]);

                if (neighborNodeData.ContainsKey("NeighbourNodeLong"))
                    neighbourNode.NeighbourNodeLong = Convert.ToDouble(neighborNodeData["NeighbourNodeLong"]);

                if (neighborNodeData.ContainsKey("FloorNo"))
                    neighbourNode.FloorNo = Convert.ToInt32(neighborNodeData["NeighbourNodeLong"]);

                if (neighborNodeData.ContainsKey("DistFrmPrimaryNode"))
                    neighbourNode.DistFrmPrimaryNode = Convert.ToDouble(neighborNodeData["DistFrmPrimaryNode"]);

                if (neighborNodeData.ContainsKey("BuildingID"))
                    neighbourNode.BuildingID = neighborNodeData["BuildingID"].ToString();

                if (neighborNodeData.ContainsKey("PrimaryNodeID"))
                    neighbourNode.PrimaryNodeID = neighborNodeData["PrimaryNodeID"].ToString();

                neighborNodes.Add(neighbourNode);
            }

            return neighborNodes;
        }

        /// <summary>
        /// This method returns all the Neighbor nodes of the given primary node name.
        /// </summary>
        /// <param name="primaryNodeName"></param>
        /// <returns>List of NeighbourNode or empty list.</returns>
        public async Task<List<NeighbourNode>> GetNeighborNodesByPrimaryNodeName(string primaryNodeName)
        {
            List<NeighbourNode> neighborNodes = new List<NeighbourNode>();

            var PrimaryNode = await GetPrimaryNodeByName(primaryNodeName);

            if (PrimaryNode == null) return neighborNodes;

            var resultedSnapshot = await FirebaseHelper.dbRef.Child("NeighbourNodes").OrderByChild("PrimaryNodeID").EqualTo(PrimaryNode.PrimaryNodeID).GetValueAsync();

            if (resultedSnapshot == null || resultedSnapshot.Value == null) return neighborNodes;

            var nodesDict = resultedSnapshot.Value as IDictionary<string, object>;

            NeighbourNode neighbourNode;
            foreach (var node in nodesDict)
            {
                neighbourNode = new NeighbourNode
                {
                    NeighbourNodeID = node.Key
                };

                var neighborNodeData = node.Value as IDictionary<string, object>;

                if (neighborNodeData.ContainsKey("NeighbourNodeName"))
                    neighbourNode.NeighbourNodeName = neighborNodeData["NeighbourNodeName"].ToString();

                if (neighborNodeData.ContainsKey("NeighbourNodeLat"))
                    neighbourNode.NeighbourNodeLat = Convert.ToDouble(neighborNodeData["NeighbourNodeLat"]);

                if (neighborNodeData.ContainsKey("NeighbourNodeLong"))
                    neighbourNode.NeighbourNodeLong = Convert.ToDouble(neighborNodeData["NeighbourNodeLong"]);

                if (neighborNodeData.ContainsKey("FloorNo"))
                    neighbourNode.FloorNo = Convert.ToInt32(neighborNodeData["NeighbourNodeLong"]);

                if (neighborNodeData.ContainsKey("DistFrmPrimaryNode"))
                    neighbourNode.DistFrmPrimaryNode = Convert.ToDouble(neighborNodeData["DistFrmPrimaryNode"]);

                if (neighborNodeData.ContainsKey("BuildingID"))
                    neighbourNode.BuildingID = neighborNodeData["BuildingID"].ToString();

                if (neighborNodeData.ContainsKey("PrimaryNodeID"))
                    neighbourNode.PrimaryNodeID = neighborNodeData["PrimaryNodeID"].ToString();

                neighborNodes.Add(neighbourNode);
            }

            return neighborNodes;
        }

        /// <summary>
        /// Gets all Neighbor nodes by buildig id and floor no.
        /// </summary>
        /// <param name="buildigID">Id of the building.</param>
        /// <param name="floorNo">Floor no.</param>
        /// <returns>List of neighbor nodes.</returns>
        public async Task<List<NeighbourNode>> GetNeighborNodesByBuildingAndFloor(string buildigID, int floorNo)
        {
            List<NeighbourNode> neighborNodes = new List<NeighbourNode>();

            var resultedSnapshot = await FirebaseHelper.dbRef.Child("NeighbourNodes").OrderByChild("BuildingID").EqualTo(buildigID).GetValueAsync();

            if (resultedSnapshot == null || resultedSnapshot.Value == null) return neighborNodes;

            var nodesDict = resultedSnapshot.Value as IDictionary<string, object>;

            NeighbourNode neighbourNode;
            foreach (var node in nodesDict)
            {
                neighbourNode = new NeighbourNode
                {
                    NeighbourNodeID = node.Key
                };

                var neighborNodeData = node.Value as IDictionary<string, object>;

                if (neighborNodeData.ContainsKey("FloorNo"))
                    neighbourNode.FloorNo = Convert.ToInt32(neighborNodeData["NeighbourNodeLong"]);

                if (neighbourNode.FloorNo != floorNo) continue;

                if (neighborNodeData.ContainsKey("NeighbourNodeName"))
                    neighbourNode.NeighbourNodeName = neighborNodeData["NeighbourNodeName"].ToString();

                if (neighborNodeData.ContainsKey("NeighbourNodeLat"))
                    neighbourNode.NeighbourNodeLat = Convert.ToDouble(neighborNodeData["NeighbourNodeLat"]);

                if (neighborNodeData.ContainsKey("NeighbourNodeLong"))
                    neighbourNode.NeighbourNodeLong = Convert.ToDouble(neighborNodeData["NeighbourNodeLong"]);


                if (neighborNodeData.ContainsKey("DistFrmPrimaryNode"))
                    neighbourNode.DistFrmPrimaryNode = Convert.ToDouble(neighborNodeData["DistFrmPrimaryNode"]);

                if (neighborNodeData.ContainsKey("BuildingID"))
                    neighbourNode.BuildingID = neighborNodeData["BuildingID"].ToString();

                if (neighborNodeData.ContainsKey("PrimaryNodeID"))
                    neighbourNode.PrimaryNodeID = neighborNodeData["PrimaryNodeID"].ToString();

                neighborNodes.Add(neighbourNode);
            }

            return neighborNodes;
        }
    }
}