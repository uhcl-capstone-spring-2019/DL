﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace Com.Uhcl.UhclNavigator
{
    public class GeotagHandler : MonoBehaviour
    {

        #region Exterior Geotag Fields
        public InputField GeoTagName;
        public InputField latitude;
        public InputField longitude;
        public Dropdown colliderNameDrpdn;
        #endregion

        private string currentSceneName = string.Empty;
        private List<Collider> allColliders = new List<Collider>();

        async void Start()
        {
            try
            {
                currentSceneName = SceneManager.GetActiveScene().name;

                if (currentSceneName == "Exterior Geotag")
                {
                    var allColliderResult = await new ColliderDAL().GetAllCollidersAsync();
                    if (allColliderResult != null && allColliderResult.Any())
                    {
                        allColliders = allColliderResult;
                        foreach (var collider in allColliders)
                        {
                            colliderNameDrpdn.options.Add(new Dropdown.OptionData(collider.colliderName));
                        }
                    }
                }
            }
            catch (System.Exception ex)
            {
                Debug.LogError(ex.InnerException.Message);
            }
        }

        public async void CreateExteriorGeotagAsync()
        {
            #region Validations
            if (string.IsNullOrEmpty(GeoTagName.text))
            {
                Debug.LogError("Please enter geotag name.");
                return;
            }
            if (string.IsNullOrEmpty(latitude.text))
            {
                Debug.LogError("Please enter latitude.");
                return;
            }
            if (string.IsNullOrEmpty(longitude.text))
            {
                Debug.LogError("Please enter longitude.");
                return;
            }
            if (colliderNameDrpdn.options[colliderNameDrpdn.value].text == "--Select--")
            {
                Debug.LogError("Please select collider name.");
                return;
            }
            #endregion

            try
            {
                string colliderName = colliderNameDrpdn.options[colliderNameDrpdn.value].text;
                string colliderID = allColliders.FirstOrDefault(C => C.colliderName == colliderName).ColliderID;

                Geotag geotag = new Geotag()
                {
                    geotagName = GeoTagName.text,
                    latitude = double.Parse(latitude.text),
                    longitude = double.Parse(longitude.text),
                    colliderID = colliderID
                };

                geotag.GeotagID = await new GeotagDAL().CreateExteriorGeotagAsync(geotag);

                if (!string.IsNullOrEmpty(geotag.GeotagID))
                {
                    Debug.Log("Geotag created with id : "+ geotag.GeotagID);
                }
            }
            catch (System.Exception ex)
            {
                Debug.LogError(ex.InnerException.Message);
            }
        }
    }
}
