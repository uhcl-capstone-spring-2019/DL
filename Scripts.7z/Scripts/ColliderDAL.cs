﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;
using UnityEngine;

namespace Com.Uhcl.UhclNavigator
{
    public class ColliderDAL
    {
        public async Task<string> CreateColliderAsync(Collider colliderData)
        {
            colliderData.ColliderID = Guid.NewGuid().ToString().Replace("-", "");
            string colliderDataJson = JsonUtility.ToJson(colliderData);
            var createColliderTask =  FirebaseHelper.dbRef.Child("Colliders").Child(colliderData.ColliderID).SetRawJsonValueAsync(colliderDataJson);
            await createColliderTask;
            if (createColliderTask.IsFaulted)
            {
                colliderData.ColliderID = string.Empty;
            }
            return colliderData.ColliderID;
        }

        public async Task<List<Collider>> GetAllCollidersAsync()
        {
            List<Collider> allColliders = new List<Collider>();

            var collidersSnapshot = await FirebaseHelper.dbRef.Child("Colliders").GetValueAsync();

            if (collidersSnapshot != null && collidersSnapshot.HasChildren)
            {
                var colliderDictionary = collidersSnapshot.Value as IDictionary<string, object>;
                Collider currentCollider;
                foreach (var collider in colliderDictionary)
                {
                    currentCollider = new Collider();
                    currentCollider.ColliderID = collider.Key;

                    var colliderData = collider.Value as IDictionary<string, object>;

                    if (colliderData.ContainsKey("colliderName"))
                        currentCollider.colliderName = colliderData["colliderName"].ToString();

                    if (colliderData.ContainsKey("colliderShape"))
                        currentCollider.colliderShape = colliderData["colliderShape"].ToString();

                    allColliders.Add(currentCollider);
                }

            }

            return allColliders;
        }
    }
}
