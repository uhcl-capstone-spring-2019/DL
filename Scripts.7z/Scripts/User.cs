﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Com.Uhcl.UhclNavigator
{
    [Serializable]
    public class User
    {
        [SerializeField]
        private string userName;

        private DateTime lastLoginTime;

        [SerializeField]
        private long lastLoginTimestamp;

        [SerializeField]
        private List<string> roles;

        [SerializeField]
        private bool isActive;

        private DateTime createdOn;

        [SerializeField]
        private long createdOnTimestamp;

        [SerializeField]
        private bool isDeleted;

        public string UserName { get { return userName; } set { userName = value; } }
        public List<string> UserRoles { get { return roles; } set { roles = value; } }
        public bool IsActive { get { return isActive; } set { isActive = value; } }
        public bool IsDeleted { get { return isDeleted; } set { isDeleted = value; } }


        public string UserID { get; set; }
        public string EmailID { get; set; }
        public string Password { get; set; }

        public DateTime LastLoginTime
        {
            get { return lastLoginTime; }
            set
            {
                lastLoginTime = value;
                lastLoginTimestamp = value.Ticks;
            }
        }

        public DateTime CreatedOn
        {
            get { return createdOn; }
            set
            {
                createdOn = value;
                createdOnTimestamp = value.Ticks;
            }
        }

    }
}
