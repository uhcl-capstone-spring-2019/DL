﻿using Firebase.Database;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace Com.Uhcl.UhclNavigator
{
    public class BuildingHandler : MonoBehaviour
    {
        public InputField buildingNameField;
        public InputField latitudeField;
        public InputField longitudeField;
        public Dropdown isExteriorDrpdn;

        /// <summary>
        /// This method will be executed when a user clicks save buildign button.
        /// </summary>
        public void OnClickSaveBuilding()
        {
            Building building = new Building();
            building.BuildingName = buildingNameField.text;
            building.Latitude = Convert.ToDouble(latitudeField.text);
            building.Longitude = Convert.ToDouble(longitudeField.text);
            building.CreatedOn = DateTime.Now;
            // building.IsExterior = Convert.ToBoolean(isExteriorDrpdn.options[isExteriorDrpdn.value].text);

            string createdBuildingID = new BuildingDAL().CreateBuildingAsync(building);

            if (string.IsNullOrEmpty(createdBuildingID))
            {
                Debug.Log("Building Not Saved.");
            }
            else
            {
                Debug.Log("Building Saved in DB With ID: " + createdBuildingID);
            }
        }

        public void OnNextClick()
        {
            new BuildingDAL().GetBuildingsAsync().ContinueWith(B => {

                if (B.Exception == null)
                {
                    var buildings = B.Result;
                    foreach (var building in buildings)
                    {
                        Debug.Log("Building ID: " + building.BuildingID);
                        Debug.Log("Building Name: " + building.BuildingName);
                        Debug.Log("Building Lat: " + building.Latitude);
                        Debug.Log("Building Long: " + building.Longitude);
                        Debug.Log("------------------------------------");

                    }
                }
            });
        }

        public void SignOut()
        {
            FirebaseHelper.SignOut();
            UnityEngine.SceneManagement.SceneManager.LoadScene("login");
        }
    }

}