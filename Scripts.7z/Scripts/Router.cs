﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Com.Uhcl.UhclNavigator
{
    public class Router
    {
        public string RouterID { get; set; }
        [SerializeField]
        private string bssid;
        [SerializeField]
        private double latitude;
        [SerializeField]
        private double longitude;
        [SerializeField]
        private int floor;
        [SerializeField]
        private string buildingID;
        [SerializeField]
        private string routerType;

        public string BSSID
        {
            get { return bssid; }
            set { bssid = value; }
        }

        public double Latitude
        {
            get { return latitude; }
            set { latitude = value; }
        }

        public double Longitude
        {
            get { return longitude; }
            set { longitude = value; }
        }

        public int Floor
        {
            get { return floor; }
            set { floor = value; }
        }

        public string BuildingID
        {
            get { return buildingID; }
            set { buildingID = value; }
        }

        public string RouterType
        {
            get { return routerType; }
            set { routerType = value; }
        }

    }
}
