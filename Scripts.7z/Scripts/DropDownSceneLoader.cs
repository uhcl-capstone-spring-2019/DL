﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class DropDownSceneLoader : MonoBehaviour {

    //Attach this script to a Dropdown GameObject
    Dropdown m_Dropdown;
    SceneLoader load =  new  SceneLoader();
    List<Dropdown.OptionData> options = new List<Dropdown.OptionData>();
    int indexValue = 0;  
   
    void Start ()
    {
        m_Dropdown = GetComponent<Dropdown>();       
       foreach(Dropdown.OptionData allVal in m_Dropdown.options )
        {
            options.Add(allVal); 
        }    
        m_Dropdown.onValueChanged.AddListener(delegate { myDropdownValueChangedHandler(m_Dropdown); });     
    }

    void Destroy()
    {
        m_Dropdown.onValueChanged.RemoveAllListeners();
    }

    private void myDropdownValueChangedHandler(Dropdown target)
    {     
      
        Debug.Log("selected: " + target.value);
        indexValue = target.value;

        string selectedValue = target.options[indexValue].text;

        if (selectedValue == "create enviorment")
        {
            switch (selectedValue)
            {
                case "create enviorment":
                    load.LoadSceneCreateEnvironment();
                    break;
                case "create building":
                    load.LoadSceneCreateBuilding();

                    break;
                case "Create Room":
                    load.LoadSceneCreateRoom();
                    break;
                case "Primary nodes":
                    load.LoadSceneCreatePrimaryNode();
                    break;
                case "neighbor node":
                    load.LoadSceneCreateSecondaryNode();
                    break;
                case "Collider":
                    load.LoadSceneCollider();
                    break;

            }
        }
    }

    private void HideOrShow(bool hide)
    {
       if(hide==true)
        {


        }

       else
        {

        }
    }

    
    void Update () {
      //m_Dropdown.options[m_Dropdown.value].text.
        
       
    }


    public void AddDropDownValue(Dropdown.OptionData Value)
    {
        if (!m_Dropdown.options.Contains(Value))
        {
            options.Add(Value);
            m_Dropdown.AddOptions(options);
        }
    }


}
 