﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class info : MonoBehaviour {

    public void LoadScene(int SceneIndex )
    {
        SceneManager.LoadScene(SceneIndex);
        //DropDownSceneLoader drop = new DropDownSceneLoader();
        //Dropdown.OptionData va = new Dropdown.OptionData();
        //va.text = "create building";
        //drop.AddDropDownValue(va);
    }
}
