﻿using Firebase.Database;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UnityEngine;

namespace Com.Uhcl.UhclNavigator
{
    public class RoomDAL
    {
        public void CreateRoomCategoryAsync(string roomCategory)
        {
            string roomCategoryID = Guid.NewGuid().ToString().Replace("-", "");
            FirebaseHelper.dbRef.Child("RoomCategories").Child(roomCategoryID).SetValueAsync(roomCategory).ContinueWith(T =>
            {
                if (!T.IsFaulted)
                {
                    Debug.Log("Room category created with ID : " + roomCategoryID);
                }
            });
        }

        public async Task<List<RoomCategory>> GetAllRoomCategoriesAsync()
        {
            List<RoomCategory> roomCategoryList = new List<RoomCategory>();
            DataSnapshot categoriesSnapshot = await FirebaseHelper.dbRef.Child("RoomCategories").GetValueAsync();

            IDictionary<string, object> allCategories = categoriesSnapshot.Value as IDictionary<string, object>;
            foreach (var category in allCategories)
            {
                RoomCategory cat = new RoomCategory();
                cat.RoomCategoryID = category.Key;
                cat.Category = category.Value as string;
                roomCategoryList.Add(cat);
            }

            return roomCategoryList;
        }

        public async Task<List<Room>> getRoomsByBuildingIDAsync(string buildingID)
        {
            List<Room> rooms = new List<Room>();

            var resultedSnapshot = await FirebaseHelper.dbRef.Child("Rooms").OrderByChild("buildingID").EqualTo(buildingID).GetValueAsync();

            var roomsDictionary = resultedSnapshot.Value as IDictionary<string, object>;

            if (roomsDictionary == null)
            {
                return rooms;
            }

            Room currentRoom = null;
            foreach (var room in roomsDictionary)
            {
                currentRoom = new Room
                {
                    RoomID = room.Key
                };
                var roomData = room.Value as IDictionary<string, object>;

                if (roomData.ContainsKey("buildingID"))
                    currentRoom.BuildingID = roomData["buildingID"].ToString();

                if (roomData.ContainsKey("categoryID"))
                    currentRoom.CategoryID = roomData["categoryID"].ToString();

                if (roomData.ContainsKey("colliderID"))
                    currentRoom.ColliderID = roomData["colliderID"].ToString();

                if (roomData.ContainsKey("floorNo"))
                    currentRoom.FloorNo = Convert.ToInt32(roomData["floorNo"]);

                if (roomData.ContainsKey("latitude"))
                    currentRoom.Latitude = Convert.ToDouble(roomData["latitude"]);

                if (roomData.ContainsKey("longitude"))
                    currentRoom.Longitude = Convert.ToDouble(roomData["longitude"]);

                if (roomData.ContainsKey("roomNo"))
                    currentRoom.RoomNo = roomData["roomNo"].ToString();

                if (roomData.ContainsKey("roomName"))
                    currentRoom.RoomName = roomData["roomName"].ToString();

                if (roomData.ContainsKey("isExterior"))
                    currentRoom.IsExterior = Convert.ToBoolean(roomData["isExterior"]);

                rooms.Add(currentRoom);
            }

            return rooms;
        }

        public async Task<string> CreateRoomAsync(Room room)
        {
            room.RoomID = Guid.NewGuid().ToString().Replace("-", "");
            var createRoomTask = FirebaseHelper.dbRef.Child("Rooms").Child(room.RoomID).SetRawJsonValueAsync(JsonUtility.ToJson(room));
            await createRoomTask;
            if (createRoomTask.IsFaulted)
            {
                room.RoomID = string.Empty;
            }

            return room.RoomID;
        }

        public async Task<List<Room>> GetAllRoomsAsync()
        {
            List<Room> allRooms = new List<Room>();
            DataSnapshot routerSnapshot = await FirebaseHelper.dbRef.Child("Rooms").GetValueAsync();

            if (routerSnapshot != null && routerSnapshot.ChildrenCount > 0)
            {
                var roomDictionary = routerSnapshot.Value as IDictionary<string, object>;
                Room room = null;
                foreach (var item in roomDictionary)
                {
                    room = new Room();
                    room.RoomID = item.Key;
                    IDictionary<string, object> otherRoomData = item.Value as IDictionary<string, object>;
                    if (otherRoomData.ContainsKey("buildingID")) room.BuildingID = otherRoomData["buildingID"].ToString();
                    if (otherRoomData.ContainsKey("categoryID")) room.CategoryID = otherRoomData["categoryID"].ToString();
                    if (otherRoomData.ContainsKey("colliderID")) room.ColliderID = otherRoomData["colliderID"].ToString();
                    if (otherRoomData.ContainsKey("floorNo")) room.FloorNo = Convert.ToInt32(otherRoomData["floorNo"]);
                    if (otherRoomData.ContainsKey("latitude")) room.Latitude = Convert.ToDouble(otherRoomData["latitude"]);
                    if (otherRoomData.ContainsKey("longitude")) room.Longitude = Convert.ToDouble(otherRoomData["longitude"]);
                    if (otherRoomData.ContainsKey("roomNo")) room.RoomNo = otherRoomData["roomNo"].ToString();
                    if (otherRoomData.ContainsKey("roomName")) room.RoomName = otherRoomData["roomName"].ToString();
                    //   if (otherRoomData.ContainsKey("isExterior")) room.IsExterior = Convert.ToBoolean(otherRoomData["isExterior"]);
                    allRooms.Add(room);
                }
            }

            return allRooms;
        }

        public async Task<Room> GetRoomByRoomID(string roomID)
        {
            Room room = null;

            var roomSnapshot = await FirebaseHelper.dbRef.Child("Rooms").Child(roomID).GetValueAsync();

            if (roomSnapshot == null || roomSnapshot.Value == null) return room;

            room = new Room()
            {
                RoomID = roomSnapshot.Key
            };

            var roomDict = roomSnapshot.Value as IDictionary<string, object>;

            if (roomDict.ContainsKey("roomNo")) room.RoomNo = roomDict["roomNo"].ToString();
            if (roomDict.ContainsKey("latitude")) room.Latitude = Convert.ToDouble(roomDict["latitude"]);
            if (roomDict.ContainsKey("longitude")) room.Longitude = Convert.ToDouble(roomDict["longitude"]);
            if (roomDict.ContainsKey("floorNo")) room.FloorNo = Convert.ToInt32(roomDict["floorNo"]);
            if (roomDict.ContainsKey("colliderID")) room.ColliderID = roomDict["colliderID"].ToString();
            if (roomDict.ContainsKey("categoryID")) room.CategoryID = roomDict["categoryID"].ToString();
            if (roomDict.ContainsKey("buildingID")) room.BuildingID = roomDict["buildingID"].ToString();
            if (roomDict.ContainsKey("roomName")) room.RoomName = roomDict["roomName"].ToString();
            // if (roomDict.ContainsKey("isExterior")) room.IsExterior = Convert.ToBoolean(roomDict["isExterior"]);

            if (room != null && !string.IsNullOrEmpty(room.BuildingID))
            {
                Building roomBuilding = await new BuildingDAL().GetBuildingByBuildingID(room.BuildingID);
                room.buildingDetail = roomBuilding;
            }

            return room;
        }

        public async Task<Room> GetRoomByRoomNo(string roomNo)
        {
            Room room = null;

            var roomSnapshot = await FirebaseHelper.dbRef.Child("Rooms").OrderByChild("roomNo").EqualTo(roomNo).GetValueAsync();

            if (roomSnapshot == null || roomSnapshot.Value == null) return room;

            var allrooms = roomSnapshot.Value as IDictionary<string, object>;

            var firstRoom = allrooms.FirstOrDefault();

            room = new Room() { RoomID = firstRoom.Key };

            var roomDict = firstRoom.Value as IDictionary<string, object>;

            if (roomDict.ContainsKey("roomNo")) room.RoomNo = roomDict["roomNo"].ToString();
            if (roomDict.ContainsKey("latitude")) room.Latitude = Convert.ToDouble(roomDict["latitude"]);
            if (roomDict.ContainsKey("longitude")) room.Longitude = Convert.ToDouble(roomDict["longitude"]);
            if (roomDict.ContainsKey("floorNo")) room.FloorNo = Convert.ToInt32(roomDict["floorNo"]);
            if (roomDict.ContainsKey("colliderID")) room.ColliderID = roomDict["colliderID"].ToString();
            if (roomDict.ContainsKey("categoryID")) room.CategoryID = roomDict["categoryID"].ToString();
            if (roomDict.ContainsKey("buildingID")) room.BuildingID = roomDict["buildingID"].ToString();
            if (roomDict.ContainsKey("roomName")) room.RoomName = roomDict["roomName"].ToString();
            //  if (roomDict.ContainsKey("isExterior")) room.IsExterior = Convert.ToBoolean(roomDict["isExterior"]);

            if (room != null && !string.IsNullOrEmpty(room.BuildingID))
            {
                Building roomBuilding = await new BuildingDAL().GetBuildingByBuildingID(room.BuildingID);
                room.buildingDetail = roomBuilding;
            }


            return room;
        }

        public async Task<Room> GetRoomByRoomName(string roomName)
        {
            Room room = null;
            var roomSnapshot = await FirebaseHelper.dbRef.Child("Rooms").OrderByChild("roomName").EqualTo(roomName).GetValueAsync();
            if (roomSnapshot == null || roomSnapshot.Value == null) return room;
            var allrooms = roomSnapshot.Value as IDictionary<string, object>;
            var firstRoom = allrooms.FirstOrDefault();
            room = new Room() { RoomID = firstRoom.Key };
            var roomDict = firstRoom.Value as IDictionary<string, object>;

            if (roomDict.ContainsKey("roomNo")) room.RoomNo = roomDict["roomNo"].ToString();
            if (roomDict.ContainsKey("latitude")) room.Latitude = Convert.ToDouble(roomDict["latitude"]);
            if (roomDict.ContainsKey("longitude")) room.Longitude = Convert.ToDouble(roomDict["longitude"]);
            if (roomDict.ContainsKey("floorNo")) room.FloorNo = Convert.ToInt32(roomDict["floorNo"]);
            if (roomDict.ContainsKey("colliderID")) room.ColliderID = roomDict["colliderID"].ToString();
            if (roomDict.ContainsKey("categoryID")) room.CategoryID = roomDict["categoryID"].ToString();
            if (roomDict.ContainsKey("buildingID")) room.BuildingID = roomDict["buildingID"].ToString();
            if (roomDict.ContainsKey("roomName")) room.RoomName = roomDict["roomName"].ToString();
            // if (roomDict.ContainsKey("isExterior")) room.IsExterior = Convert.ToBoolean(roomDict["isExterior"]);

            if (room != null && !string.IsNullOrEmpty(room.BuildingID))
            {
                Building roomBuilding = await new BuildingDAL().GetBuildingByBuildingID(room.BuildingID);
                room.buildingDetail = roomBuilding;
            }

            return room;
        }

    }
}