﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneLoader : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

        public void LoadSceneNewProject()
    {
        SceneManager.LoadScene("create enviorment");
    }

    public void LoadSceneCreateEnvironment()
    {
        SceneManager.LoadScene("create enviorment");
    }
    public void LoadSceneCreateBuilding()
    {
        SceneManager.LoadScene("create building");
    }
    public void LoadSceneCreateRoom()
    {
        SceneManager.LoadScene("Create Room");
    }
    public void LoadSceneCreatePrimaryNode()
    {
        SceneManager.LoadScene("Primary nodes");
    }
    public void LoadSceneCreateSecondaryNode()
    {
        SceneManager.LoadScene("neighbor node");
    }
    public void LoadSceneCollider()
    {
        SceneManager.LoadScene("Collider");
    }


}
