﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UnityEngine;

namespace Com.Uhcl.UhclNavigator
{
    public class PoiDAL
    {
        public async Task<POI> GetPOI(string name)
        {

            var snapshot = await FirebaseHelper.dbRef.Child("PointOfInterest").OrderByChild("Name").EqualTo(name).GetValueAsync();

            if (snapshot.Value == null)
            {
                return null;
            }

            var dict = snapshot.Value as IDictionary<string, object>;

            if (dict == null) return null;

            var firstPoi = dict.FirstOrDefault();

            POI poi = new POI()
            {
                PoiID = firstPoi.Key
            };

            var poiData = firstPoi.Value as IDictionary<string, object>;

            if (poiData.ContainsKey("Name"))
                poi.Name = poiData["Name"].ToString();

            if (poiData.ContainsKey("TableName"))
                poi.TableName = poiData["TableName"].ToString();

            if (poiData.ContainsKey("TableColumnName"))
                poi.TableColumnName = poiData["TableColumnName"].ToString();

            if (poiData.ContainsKey("isExterior"))
                poi.isExterior = Convert.ToBoolean(poiData["isExterior"]);

            return poi;
        }


        public async Task<List<POI>> GetAllPOI()
        {
            List<POI> allPoi = new List<POI>();
            var snapshot = await FirebaseHelper.dbRef.Child("PointOfInterest").GetValueAsync();

            if (snapshot.Value == null)
            {
                return null;
            }

            var dict = snapshot.Value as IDictionary<string, object>;

            POI poi;
            foreach (var item in dict)
            {
                poi = new POI()
                {
                    PoiID = item.Key
                };

                var poiData = item.Value as IDictionary<string, object>;

                if (poiData.ContainsKey("Name"))
                    poi.Name = poiData["Name"].ToString();

                if (poiData.ContainsKey("TableName"))
                    poi.TableName = poiData["TableName"].ToString();

                if (poiData.ContainsKey("TableColumnName"))
                    poi.TableColumnName = poiData["TableColumnName"].ToString();

                if (poiData.ContainsKey("isExterior"))
                    poi.isExterior = Convert.ToBoolean(poiData["isExterior"]);

                allPoi.Add(poi);
            }

            return allPoi;
        }

    }

}
