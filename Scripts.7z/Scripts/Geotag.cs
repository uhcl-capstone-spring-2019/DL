﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
namespace Com.Uhcl.UhclNavigator
{
    [Serializable]
    public class Geotag
    {
        public string GeotagID { get; set; }
        public string geotagName;
        public double latitude;
        public double longitude;
        public string colliderID;
    }
}
