﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;
using UnityEngine;

namespace Com.Uhcl.UhclNavigator
{
    public class GeotagDAL
    {
        public async Task<string> CreateExteriorGeotagAsync(Geotag geotagData)
        {
            geotagData.GeotagID = Guid.NewGuid().ToString().Replace("-", "");

            string json = JsonUtility.ToJson(geotagData);
            var task = FirebaseHelper.dbRef.Child("ExteriorGeotag").Child(geotagData.GeotagID).SetRawJsonValueAsync(json);
            await task;

            if (task.IsFaulted)
            {
                geotagData.GeotagID = string.Empty;
            }

            return geotagData.GeotagID;
        }
    }
}
