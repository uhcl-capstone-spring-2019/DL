﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Com.Uhcl.UhclNavigator
{
    public class Building
    {
        public Building()
        {
            isActive = true;
        }

        [SerializeField]
        private string buildingName;
        [SerializeField]
        private double latitude;
        [SerializeField]
        private double longitude;
        [SerializeField]
        private DateTime createdOn;
        [SerializeField]
        private bool isActive;
        //  [SerializeField]
        private bool isExterior;

        /// <summary>
        /// Auto generated Building ID.
        /// </summary>
        public string BuildingID { get; set; }

        /// <summary>
        /// Name of the Building
        /// </summary>
        public string BuildingName { get { return buildingName; } set { buildingName = value; } }

        /// <summary>
        /// Latitude
        /// </summary>
        public double Latitude { get { return latitude; } set { latitude = value; } }

        /// <summary>
        /// Longitude
        /// </summary>
        public double Longitude { get { return longitude; } set { longitude = value; } }

        /// <summary>
        /// Building Record Creation Time.
        /// </summary>
        public DateTime CreatedOn { get { return createdOn; } set { createdOn = value; } }

        /// <summary>
        /// Active/Inactive Flag.
        /// </summary>
        public bool IsActive { get { return isActive; } set { isActive = value; } }

        //  public bool IsExterior { get { return isExterior; } set { isExterior = value; } }
    }
}
