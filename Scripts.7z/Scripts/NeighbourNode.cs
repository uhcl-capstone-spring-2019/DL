﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace Com.Uhcl.UhclNavigator
{
    public class NeighbourNode
    {
        public string NeighbourNodeID { get; set; }

        public string PrimaryNodeID;
        public string NeighbourNodeName;
        public double NeighbourNodeLat;
        public double NeighbourNodeLong;
        public double DistFrmPrimaryNode;
        public string BuildingID;
        public int FloorNo;
    }
}
